module.exports = require('./discord_erlpack.node');
